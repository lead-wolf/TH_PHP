<h1>Thêm mới danh mục</h1>
<form action="/category/store" method="POST">
    <label for="name">Tên danh mục:</label>
    <input type="text" id="name" name="name" required>
    <br>
    <label for="description">Mô tả:</label>
    <textarea id="description" name="description"></textarea>
    <br>
    <button type="submit">Lưu</button>
</form>
