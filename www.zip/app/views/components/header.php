<header class="bg-warning py-3">
    <div class="container d-flex justify-content-between align-items-center">
        <h1 class="text-white mb-0">SEA FRUITS - CỬA HÀNG HẢI SẢN</h1>
        <nav>
            <ul class="nav">
                <li class="nav-item"><a href="/" class="nav-link text-white">Trang chủ</a></li>
                <li class="nav-item"><a href="/products" class="nav-link text-white">Sản phẩm</a></li>
                <li class="nav-item"><a href="/category" class="nav-link text-white">Danh mục</a></li>
            </ul>
        </nav>
    </div>
</header>